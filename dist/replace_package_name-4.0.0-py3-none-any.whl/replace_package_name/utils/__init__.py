

def print_hello():
    print("hello")
